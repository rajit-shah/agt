The Sample client is packaged as compressed .zip file containing the client application with all dependencies. 

How to start the application:
 - unzip the compressed .zip file 
 - open shell (in linux) or Command (in windows) and browse into the unzipped location
 - locate sample-client.jar or sample-client.bat file  
 - run java -jar file-scanner-service.jar {path} or sample-client.bat {path} to run the client
 
 Note: The client takes a directory path as an argument. The client, by default, tries to connect to the service running at localhost:8080.   
 

Requirements to run: 
 - JRE-8 installed and JAVA_HOME must point to where the JRE is installed

 